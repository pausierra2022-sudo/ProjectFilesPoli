package salesreport;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

/**
 * This main class generates the following test files:
 * - Products.txt
 * - vendors.txt
 * - ventas_ID.txt (sales per existing seller)
 */
public class GenerateInfoFiles {

    private static final Random random = new Random();

    public static void main(String[] args) {
        try {
            // Creating output directory if, it doesn´t exist
            File outputDir = new File("output");
            if (!outputDir.exists()) {
                outputDir.mkdirs();
            }

            int productCount = 15;
            int salesmanCount = 5;

            List<Integer> productIds = createProductsFile(productCount);
            List<Long> salesmanIds = createSalesManInfoFile(salesmanCount);

            // It generates random sales for each seller
            for (Long salesmanId : salesmanIds) {
                createSalesMenFile(productIds, salesmanId);
            }

            System.out.println("Archivos de prueba generados correctamente en la carpeta output/");
        } catch (Exception e) {
            System.err.println("Error generando archivos: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * To create a sales file for an especific seller.
     */
    public static void createSalesMenFile(List<Integer> productIds, long salesmanId) throws IOException {
        int randomSalesCount = random.nextInt(5) + 1; // entre 1 y 5 ventas por archivo

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("output/ventas_" + salesmanId + ".txt"))) {
            writer.write("CC;" + salesmanId);
            writer.newLine();

            for (int i = 0; i < randomSalesCount; i++) {
                int productId = productIds.get(random.nextInt(productIds.size()));
                int quantity = random.nextInt(5) + 1;
                writer.write(productId + ";" + quantity);
                writer.newLine();
            }
        }
    }

    /**
     * It creates Products.txt file and return an IDs list of generated products.
     */
    public static List<Integer> createProductsFile(int countProducts) throws IOException {
        List<Integer> productIds = new ArrayList<>();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("output/Products.txt"))) {
            for (int i = 1; i <= countProducts; i++) {
                String productName = "Product" + i;
                double price = 1000 + random.nextDouble() * 9000; // precio con decimales
                writer.write(i + ";" + productName + ";" + String.format("%.2f", price));
                writer.newLine();
                productIds.add(i);
            }
        }

        return productIds;
    }

    /**
     * It creates the vendors.txt file and return an IDs list of generated sellers.
     */
    public static List<Long> createSalesManInfoFile(int salesmanCount) throws IOException {
        String[] names = {"Jennifer", "Mary", "Juana", "Elisa", "Felipe"};
        String[] lastNameList = {"Estrada", "Lopez", "Miranda", "Gutierrez", "Henao"};

        List<Long> salesmanIds = new ArrayList<>();
        Set<Long> usedIds = new HashSet<>(); // para garantizar unicidad

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("output/vendors.txt"))) {
            for (int i = 0; i < salesmanCount; i++) {
                String name = names[random.nextInt(names.length)];
                String lastName = lastNameList[random.nextInt(lastNameList.length)];

                long id;
                do {
                    id = 10000000L + random.nextInt(90000000);
                } while (usedIds.contains(id));
                usedIds.add(id);

                writer.write("CC;" + id + ";" + name + ";" + lastName);
                writer.newLine();
                salesmanIds.add(id);
            }
        }

        return salesmanIds;
    }
}
