package salesreport;

/**
 * This class represents a seller in the system
 */
public class Salesman {
    private long id;
    private String name;
    private String lastName;
    private double totalSales;

    public Salesman(long id, String name, String lastName) {
        this.id = id;
        this.name = name;
        this.lastName = lastName;
        this.totalSales = 0.0;
    }

    public long getId() { return id; }
    public String getFullName() { return name + " " + lastName; }
    public double getTotalSales() { return totalSales; }

    public void addSales(double amount) {
        this.totalSales += amount;
    }
}
