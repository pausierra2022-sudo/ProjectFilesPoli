package salesreport;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * This class generates the reports:
 * - Sellers Report organized by sales.
 * - Products Report organized by units sold.
 */
public class main {

    public static void main(String[] args) {
        try {
            // Making sure that the output directory exists
            File outputDir = new File("output");
            if (!outputDir.exists()) {
                outputDir.mkdirs();
            }

            Map<Integer, Product> products = loadProducts("output/Products.txt");
            Map<Long, Salesman> salesmen = loadSalesmen("output/vendors.txt");

            processSalesFiles("output/", products, salesmen);

            writeSalesmenReport(salesmen, "output/ReporteVendedores.csv");
            writeProductsReport(products, "output/ReporteProductos.csv");

            System.out.println("✅ Reportes generados correctamente en la carpeta output/");
        } catch (Exception e) {
            System.err.println("❌ Error generando reportes: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Upload the products from Products.txt file
     */
    private static Map<Integer, Product> loadProducts(String filePath) throws IOException {
        Map<Integer, Product> products = new HashMap<>();
        List<String> lines = Files.readAllLines(Paths.get(filePath));

        for (String line : lines) {
            String[] parts = line.split(";");
            if (parts.length != 3) {
                System.err.println("⚠️ Línea inválida en Products.txt: " + line);
                continue;
            }

            try {
                int id = Integer.parseInt(parts[0]);
                String name = parts[1];
                double price = Double.parseDouble(parts[2].replace(",", "."));

                if (id <= 0 || price <= 0) {
                    System.err.println("⚠️ Producto inválido: " + line);
                    continue;
                }

                products.put(id, new Product(id, name, price));
            } catch (NumberFormatException e) {
                System.err.println("⚠️ Error parseando producto: " + line);
            }
        }
        return products;
    }

    /**
     * Upload the sellers from vendors.txt file.
     */
    private static Map<Long, Salesman> loadSalesmen(String filePath) throws IOException {
        Map<Long, Salesman> salesmen = new HashMap<>();
        List<String> lines = Files.readAllLines(Paths.get(filePath));

        for (String line : lines) {
            String[] parts = line.split(";");
            if (parts.length != 4) {
                System.err.println("⚠️ Línea inválida en vendors.txt: " + line);
                continue;
            }

            try {
                long id = Long.parseLong(parts[1]);
                String name = parts[2];
                String lastName = parts[3];

                salesmen.put(id, new Salesman(id, name, lastName));
            } catch (NumberFormatException e) {
                System.err.println("⚠️ Error parseando vendedor: " + line);
            }
        }
        return salesmen;
    }

    /**
     * Processing all the files of sales into an indicated directory.
     */
    private static void processSalesFiles(String folderPath, Map<Integer, Product> products, Map<Long, Salesman> salesmen) throws IOException {
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(folderPath), "ventas_*.txt")) {
            for (Path entry : stream) {
                List<String> lines = Files.readAllLines(entry);

                if (lines.isEmpty()) continue;

                // Cabecera con ID del vendedor
                String[] header = lines.get(0).split(";");
                if (header.length < 2) continue;

                long salesmanId;
                try {
                    salesmanId = Long.parseLong(header[1]);
                } catch (NumberFormatException e) {
                    System.err.println("⚠️ ID de vendedor inválido en archivo: " + entry);
                    continue;
                }

                Salesman salesman = salesmen.get(salesmanId);
                if (salesman == null) {
                    System.err.println("⚠️ Vendedor no encontrado para archivo: " + entry);
                    continue;
                }

                // To process sales
                for (int i = 1; i < lines.size(); i++) {
                    String[] parts = lines.get(i).split(";");
                    if (parts.length < 2) {
                        System.err.println("⚠️ Línea inválida en " + entry + ": " + lines.get(i));
                        continue;
                    }

                    try {
                        int productId = Integer.parseInt(parts[0]);
                        int quantity = Integer.parseInt(parts[1]);

                        if (quantity <= 0) {
                            System.err.println("⚠️ Cantidad inválida en archivo " + entry + ": " + lines.get(i));
                            continue;
                        }

                        Product product = products.get(productId);
                        if (product == null) {
                            System.err.println("⚠️ Producto con ID " + productId + " no encontrado.");
                            continue;
                        }

                        double saleAmount = product.getPrice() * quantity;
                        salesman.addSales(saleAmount);
                        product.addUnitsSold(quantity);
                    } catch (NumberFormatException e) {
                        System.err.println("⚠️ Error parseando venta en " + entry + ": " + lines.get(i));
                    }
                }
            }
        }
    }

    /**
     * It generates the sellers report in CSV format.
     * Format: Fullname ; Total sales
     */
    private static void writeSalesmenReport(Map<Long, Salesman> salesmen, String filePath) throws IOException {
        List<Salesman> sortedSalesmen = salesmen.values().stream()
                .sorted(Comparator.comparingDouble(Salesman::getTotalSales).reversed())
                .collect(Collectors.toList());

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write("Vendedor;TotalVentas");
            writer.newLine();
            for (Salesman s : sortedSalesmen) {
                writer.write(s.getFullName() + ";" + String.format("%.2f", s.getTotalSales()));
                writer.newLine();
            }
        }
    }

    /**
     * It generates the products report in CSV format.
     * Format: Name ; Price ; quantity sold
     */
    private static void writeProductsReport(Map<Integer, Product> products, String filePath) throws IOException {
        List<Product> sortedProducts = products.values().stream()
                .sorted(Comparator.comparingInt(Product::getTotalUnitsSold).reversed())
                .collect(Collectors.toList());

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write("Producto;Precio;CantidadVendida");
            writer.newLine();
            for (Product p : sortedProducts) {
                writer.write(p.getName() + ";" + String.format("%.2f", p.getPrice()) + ";" + p.getTotalUnitsSold());
                writer.newLine();
            }
        }
    }
}
